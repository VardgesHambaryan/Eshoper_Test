from django.shortcuts import render
from django.views.generic import ListView, DetailView
from .models import *
# Create your views here.
class ContactListView(ListView):
    template_name = "index.html"
    
    def get(self, request):
        contacts = Contacts.objects.all()
        carusel_item_active = CaruselActive.objects.all()
        carusel_item = Carusel.objects.all()
        products = Product.objects.all()

        return render(request , self.template_name , {"contacts": contacts , 'carusel_item_active':carusel_item_active , 'carusel_item':carusel_item, 'products':products})

class LoginListView(ListView):
    template_name = 'login.html'

    def get(self, request):
        contacts = Contacts.objects.all()
        return render(request , self.template_name , {"contacts": contacts})



    
