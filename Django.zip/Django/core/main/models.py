from django.db import models

# Create your models here.
class Contacts(models.Model):
    phone = models.CharField("Phone number: ", max_length=15)
    e_mail = models.CharField("E-Mail", max_length=30)

    def __str__(self) -> str:
        return 'Contacts'

    class Meta:
        verbose_name = "Contact"
        verbose_name_plural = "Contacts"
class CaruselActive(models.Model):
    title1 = models.CharField('Title 1' , max_length = 30)
    title2 = models.CharField('Title 2' , max_length = 30)
    text = models.TextField('Text: ')
    img1 = models.ImageField('Image 1:' , upload_to='media')
    img2 = models.ImageField('Image 2:' , upload_to='media')


    def __str__(self) -> str:
        return self.title1

    class Meta:
        verbose_name = "CaruselActive"
        verbose_name_plural = "CaruselsActive"

class Carusel(models.Model):
    title1 = models.CharField('Title 1' , max_length = 30)
    title2 = models.CharField('Title 2' , max_length = 30)
    text = models.TextField('Text: ')
    img1 = models.ImageField('Image 1:' , upload_to='media')
    img2 = models.ImageField('Image 2:' , upload_to='media')


    def __str__(self) -> str:
        return self.title1

    class Meta:
        verbose_name = "Carusel"
        verbose_name_plural = "Carusels"

class Product(models.Model):
    price = models.IntegerField('Products price: ')
    img = models.ImageField('Products image: ', upload_to='media')
    name = models.CharField('Products name: ', max_length=30)

    def __str__(self) -> str:
        return self.name

    class Meta:
        verbose_name = 'Product'
        verbose_name_plural = 'Products'