from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Contacts)
admin.site.register(CaruselActive)
admin.site.register(Carusel)
admin.site.register(Product)
